﻿using System.ComponentModel.DataAnnotations;
namespace TrackingApp.DTOs

{
    public class CreateAssetDto
    {
        [Required]
        [StringLength(50)]
        public string AssetTag { get; set; } = string.Empty;
        [Required]
        [StringLength(100)]
        public string Name { get; set; } = string.Empty;
        [Required]
        [StringLength(50)]
        public string? SerialNumber { get; set; }
        
        [Required]
        public DateTime PurchaseDate { get; set; }

        [Required]
        public int CategoryId { get; set; }
    }
}
