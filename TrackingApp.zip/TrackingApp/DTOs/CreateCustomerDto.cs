﻿using System.ComponentModel.DataAnnotations;
namespace TrackingApp.DTOs
{
    public class CreateCustomerDto
    {
        [Required]
        [StringLength(100)]
        public string FullName { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required]
        [StringLength(20)]
        public string? Phone { get; set; } = string.Empty;
    }
}
