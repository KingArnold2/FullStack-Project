﻿using TrackingApp.Models;

namespace TrackingApp.DTOs
{
    public class LoanDto
    {
        public int Id { get; set; }

        public DateTime LoanDate { get; set; }
        public DateTime DueDate { get; set; }

        public DateTime? ReturnDate { get; set; }
        public int AssetId { get; set; }
        public Asset? Asset { get; set; }
        public int CustomerId { get; set; }
        public string CustomerName { get; set; } = string.Empty;

        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; } = string.Empty;

        




    }
}
