﻿using System.ComponentModel.DataAnnotations;
namespace TrackingApp.DTOs
{
    public class CreateLoanDto
    {

        [Required]
        public int AssetId { get; set; }
        [Required]
        public int CustomerId { get; set; }

        [Required]
        public int EmployeeId { get; set; }
        
        [Required]
        public DateTime DueDate {  get; set; }
    }
}
