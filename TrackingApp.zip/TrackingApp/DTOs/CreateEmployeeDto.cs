﻿using System.ComponentModel.DataAnnotations;
namespace TrackingApp.DTOs
{
    public class CreateEmployeeDto
    {   
        [Required]
        [StringLength(100)]
        public string FullName { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required]
        [StringLength(100)]
        public string Department { get; set; } = string.Empty;
    }
    
}
