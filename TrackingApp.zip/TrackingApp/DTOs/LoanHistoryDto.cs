﻿using TrackingApp.Models;
namespace TrackingApp.DTOs
{
    public class LoanHistoryDto
    {
        public int Id { get; set; }
        public string Action { get; set; } = string.Empty;

        public DateTime Timestamp { get; set; }

        public int AssetId { get; set; }

        public string AssetName { get; set; } = string.Empty;
        
        public int EmployeeId { get; set; }

        public string EmployeeName { get; set; } =string.Empty;
    }
}
