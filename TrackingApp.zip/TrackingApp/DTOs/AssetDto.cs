﻿namespace TrackingApp.DTOs
{
    public class AssetDto
    {
        public int Id { get; set; }
        public string AssetTag { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;

        public string ? SerialNumber { get; set; }

        public DateTime PurchaseDate { get; set; }
        
        public string status { get; set; } = string.Empty;

        public int CategoryId { get; set; }
        public string CategoryName { get; set; } = string.Empty;

    }
}
