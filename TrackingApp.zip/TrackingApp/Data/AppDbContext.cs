﻿using Microsoft.EntityFrameworkCore;
using TrackingApp.Models;

namespace TrackingApp.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    // DbSets properties.
    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Asset> Assets => Set<Asset>();
    public DbSet<Employee> Employees => Set<Employee>();
    public DbSet<Loan> Loans => Set<Loan>();
    public DbSet<LoanHistory> LoanHistories => Set<LoanHistory>();

    // — API relationship config.
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // relationships
        base.OnModelCreating(modelBuilder);
          modelBuilder.Entity<Asset>()
            .HasOne(a => a.Category)
            .WithMany(c => c.Assets)
            .HasForeignKey(a => a.CategoryId);

        modelBuilder.Entity<Loan>()
            .HasOne(l => l.Asset)
            .WithMany(a =>a.Loans)
            .HasForeignKey(l => l.AssetId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Loan>()
           .HasOne(l => l.Employee)
           .WithMany(e => e.Loans)
           .HasForeignKey(l => l.EmployeeId)
           .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Loan>()
            .HasOne(l => l.Customer)
            .WithMany(c => c.Loans)
            .HasForeignKey(l => l.CustomerId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Asset>()
            .HasIndex(a => a.AssetTag)
            .IsUnique();
        modelBuilder.Entity<Customer>()
            .HasIndex(c => c.Email)
            .IsUnique();

        modelBuilder.Entity<Employee>()
            .HasIndex(e => e.Email)
            .IsUnique();




    }
}