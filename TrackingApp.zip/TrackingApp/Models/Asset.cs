﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrackingApp.Models
{
    public enum AssetStatus
    {
        Available,
        OnLoan,
        Overdue,
        InRepair,
        Retired
    }

    public class Asset
    {
        public int Id { get; set; }
        public string AssetTag { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;

        public int CategoryId { get; set; }

        public DateTime PurchaseDate { get; set; }

        public string SerialNumber { get; set; } = string.Empty;

        public AssetStatus Status { get; set; } = AssetStatus.Available;

        public Category? Category { get; set; }

        public ICollection<Loan> Loans { get; set; } = new List<Loan>();
    }
}

