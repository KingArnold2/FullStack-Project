﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrackingApp.Models
{
    public enum LoanAction
    {
        Loaned,
        Returned,
        MarkedOverdue
    }

    public class LoanHistory
    {
        public int Id { get; set; }

        public LoanAction Action { get; set; }
        public DateTime Timestamp { get; set; }

        public int AssetId { get; set; }
        public string? AssetName { get; set; }
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; } = string.Empty;
    }
}

