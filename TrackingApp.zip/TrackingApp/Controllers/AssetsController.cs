﻿using TrackingApp.Data;
using TrackingApp.Models;
using Microsoft.EntityFrameworkCore;
using TrackingApp.DTOs;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
namespace TrackingApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AssetsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AssetsController(AppDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AssetDto>>> GetAssets()
        {
            var assets = await _context.Assets
                .Include(a => a.Category)
                .Select(a => new AssetDto
                {
                    Id = a.Id,
                    AssetTag = a.AssetTag,
                    Name = a.Name,
                    SerialNumber = a.SerialNumber,
                    PurchaseDate = a.PurchaseDate,
                    CategoryId = a.CategoryId,
                    CategoryName = a.Category.Name
                })
                .ToListAsync();

            return Ok(assets);
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<AssetDto>> GetAsset(int id)
        {
            var asset = await _context.Assets
                .Include(a => a.Category)
                .FirstOrDefaultAsync(a => a.Id == id);
            if (asset == null)
            {
                return NotFound();
            }
            return Ok(new AssetDto
            {
                Id = asset.Id,
                AssetTag = asset.AssetTag,
                Name = asset.Name,
                SerialNumber = asset.SerialNumber,
                PurchaseDate = asset.PurchaseDate,
                status = asset.Status.ToString(),
                CategoryId = asset.CategoryId,
                CategoryName = asset.Category.Name

            });
                
        }
        [HttpPost]
        public async Task<ActionResult<AssetDto>> CreateAsset([FromBody] CreateAssetDto dto)
        {
          var category = await _context.Categories.FindAsync(dto.CategoryId);
            if (category == null)
            {
                return BadRequest("Invalid category ID.");
            }

            var asset = new Asset
            {
                AssetTag = dto.AssetTag,
                Name = dto.Name,
                SerialNumber = dto.SerialNumber,
                PurchaseDate = dto.PurchaseDate,
                CategoryId = dto.CategoryId,
                Status = AssetStatus.Available
            };
            _context.Assets.Add(asset);
            await _context.SaveChangesAsync();
            
            var result = new AssetDto
            {
                Id = asset.Id,
                AssetTag = asset.AssetTag,
                Name = asset.Name,
                SerialNumber = asset.SerialNumber,
                PurchaseDate = asset.PurchaseDate,
                status = asset.Status.ToString(),
                CategoryId = asset.CategoryId,
                CategoryName = asset.Category.Name
            };
            return CreatedAtAction(nameof(GetAsset), new { id = asset.Id }, result);
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateAsset(int id, CreateAssetDto dto)
        {
            var asset = await _context.Assets.FindAsync(id);
            if (asset == null)
                return NotFound();
            
             var category = await _context.Categories.FindAsync(dto.CategoryId);
            if (category == null)
                return NotFound("Category not found");
            
            asset.AssetTag = dto.AssetTag;
            asset.Name = dto.Name;
            asset.SerialNumber = dto.SerialNumber;
            asset.PurchaseDate = dto.PurchaseDate;
            asset.CategoryId = dto.CategoryId;

            await _context.SaveChangesAsync();
            return NoContent();
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAsset(int id)
        {
            var asset = await _context.Assets.FindAsync(id);
            if (asset == null)
                return NotFound();
            
            _context.Assets.Remove(asset);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
