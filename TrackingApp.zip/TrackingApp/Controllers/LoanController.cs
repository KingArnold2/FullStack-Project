﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TrackingApp.Models;
using TrackingApp.Data;
using TrackingApp.DTOs;
using Microsoft.EntityFrameworkCore;

namespace TrackingApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoanController : ControllerBase
    {
        private readonly AppDbContext _context;
        public LoanController(AppDbContext context)
        {
            _context = context;
        }
        [HttpGet("active")]
        public async Task<ActionResult<IEnumerable<LoanDto>>> GetActiveLoans()
        {
            var loans = await _context.Loans
                .Include(l => l.Asset)
                .Include(l => l.Customer)
                .Include(l => l.Employee)
                .Where(l => l.ReturnDate == null)
                .OrderBy(l => l.Employee.FullName)
                .Select(l => new LoanDto
                {
                    Id = l.Id,
                    LoanDate = l.LoanDate,
                    DueDate = l.DueDate,
                    ReturnDate = l.ReturnDate,
                    AssetId = l.AssetId,
                    Asset = l.Asset,
                    CustomerId = l.CustomerId,
                    CustomerName = l.Customer.FullName,
                    EmployeeId = l.EmployeeId,
                    EmployeeName = l.Employee.FullName
                })
                .ToListAsync();

            

            return Ok(loans);
        }
        [HttpGet("{id:int}")]
        public async Task<ActionResult<LoanDto>> GetLoan(int id)
        {
            var loan = await _context.Loans
                .Include(l => l.Asset)
                .Include(l => l.Customer)
                .Include(l => l.Employee)
                .FirstOrDefaultAsync(l => l.Id == id);
            if (loan == null)
            {
                return NotFound();
            }

            var dto = new LoanDto
            {
                Id = loan.Id,
                LoanDate = loan.LoanDate,
                DueDate = loan.DueDate,
                ReturnDate = loan.ReturnDate,
                AssetId = loan.AssetId,
                Asset = loan.Asset,
                CustomerId = loan.CustomerId,
                CustomerName = loan.Customer.FullName,
                EmployeeId = loan.EmployeeId,
                EmployeeName = loan.Employee.FullName
            };

            return Ok(dto);
        }
        [HttpPost]
        public async Task<ActionResult<LoanDto>> CreateLoan(CreateLoanDto dto)
        {
            if (dto.DueDate.Date < DateTime.Now.Date)
            {
                return BadRequest("Due date cannot be in the past.");
            }

            var asset = await _context.Assets.FindAsync(dto.AssetId);
            if (asset == null)
            {
                return NotFound("Asset not found.");
            }
            var customer = await _context.Customers.FindAsync(dto.CustomerId);
            if (customer == null)
            {
                return NotFound("Customer not found.");
            }
            var employee = await _context.Employees.FindAsync(dto.EmployeeId);
            if (employee == null)
            {
                return NotFound("Employee not found.");
            }
            if (asset.Status != AssetStatus.Available)
            {
                return Conflict($"Asset '{asset.Name}' is not available (current status: {asset.Status}).");
            }
            var loan = new Loan
            {
                AssetId = dto.AssetId,
                CustomerId = dto.CustomerId,
                EmployeeId = dto.EmployeeId,
                LoanDate = DateTime.Now,
                DueDate = dto.DueDate,
                ReturnDate = null
            };

            _context.Loans.Add(loan);

            asset.Status = AssetStatus.OnLoan;

            _context.LoanHistories.Add(new LoanHistory
            {
                AssetId = asset.Id,
                Timestamp= DateTime.UtcNow,
                AssetName = asset.Name,
                EmployeeId = employee.Id,
                EmployeeName = employee.FullName,
              
            });

            await _context.SaveChangesAsync();

            var result = new LoanDto
            {
                Id = loan.Id,
                LoanDate = loan.LoanDate,
                DueDate = loan.DueDate,
                ReturnDate = loan.ReturnDate,
                AssetId = loan.AssetId,
                Asset = asset,
                CustomerId = loan.CustomerId,
                CustomerName = loan.Customer.FullName,
                EmployeeId = loan.EmployeeId,
                EmployeeName = employee.FullName
            };

            return CreatedAtAction(nameof(GetLoan), new { id = loan.Id }, result);
        }

        [HttpPatch("{id}/return")]

        public async Task<ActionResult> ReturnLoan(int id)
        {
            var loan = await _context.Loans
                .Include(l => l.Asset)
                .Include(l => l.Employee)
                .Include(l => l.Customer)
                .FirstOrDefaultAsync(l => l.Id == id);
            if (loan == null)
            {
                return NotFound();
            }
            if (loan.ReturnDate != null)
            {
                return BadRequest("This loan has already been returned.");
            }
            loan.ReturnDate = DateTime.Now;
            loan.Asset.Status = AssetStatus.Available;

            _context.LoanHistories.Add(new LoanHistory
            {
                Action = LoanAction.Returned,
                Timestamp = DateTime.UtcNow,
                AssetId = loan.Asset.Id,
                AssetName = loan.Asset.Name,
                EmployeeId = loan.Employee.Id,
                EmployeeName = loan.Employee.FullName,
              
            });
            await _context.SaveChangesAsync();

            return NoContent();
        }
      
    }
}
