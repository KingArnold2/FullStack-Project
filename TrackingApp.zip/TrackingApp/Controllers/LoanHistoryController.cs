﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TrackingApp.Models;
using TrackingApp.Data;
using Microsoft.EntityFrameworkCore;
using TrackingApp.DTOs;
using System.Reflection;

namespace TrackingApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoanHistoryController : ControllerBase

    {
        private readonly AppDbContext _context;
        public LoanHistoryController(AppDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<LoanHistoryDto>>> GetLoanHistories([FromQuery] string? action)
        {
            var query = _context.LoanHistories.AsQueryable();
            if(!string.IsNullOrEmpty(action))
            {
                if (Enum.TryParse<LoanAction>(action, true, out var parsedAction))
                    return BadRequest("invalid action value. must be loanded, Returned,or  MarkedOverdue.");
                query = query.Where(h => h.Action == parsedAction);
                
      
            }

            var history = await _context.LoanHistories
                .OrderByDescending(h => h.Timestamp)
                .Select(h => new LoanHistoryDto
                {
                    Id = h.Id,
                    Action = h.Action.ToString(),
                    Timestamp = h.Timestamp,
                    AssetId = h.AssetId,
                    AssetName = h.AssetName,
                    EmployeeId = h.EmployeeId,
                    EmployeeName = h.EmployeeName
                })
                .ToListAsync();
            return Ok(history);
        }
    }
}
