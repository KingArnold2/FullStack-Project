﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TrackingApp.DTOs;
using TrackingApp.Models;
using TrackingApp.Data;
using Microsoft.EntityFrameworkCore;

namespace TrackingApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly AppDbContext _context;
        public CustomerController(AppDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CustomerDto>>> GetCustomers()
        {
            var customers = await _context.Customers
             .Select(c => new CustomerDto
              {
                Id = c.Id,
                FullName = c.FullName,
                Email = c.Email,
                Phone = c.Phone
            }).ToListAsync();
            return Ok(customers);
        }
        [HttpGet("{id:int}")]
        public async Task<ActionResult<Customer>> GetCustomer(int id)
        {
            var customer = await _context.Customers.FindAsync(id);
            if (customer == null)
                 return NotFound();
            
            return Ok(new CustomerDto
            {
                Id = customer.Id,
                FullName = customer.FullName,
                Email = customer.Email,
                Phone = customer.Phone
            });
        }
        [HttpPost]
        public async Task<ActionResult<Customer>> CreateCustomer(CreateCustomerDto Customer)
        {
            var customer = new Customer
            {
                FullName =Customer.FullName,
                Email =   Customer.Email,
                Phone =  Customer.Phone
            };
            _context.Customers.Add(customer);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetCustomer), new { id = customer.Id }, customer);
        }
        [HttpPut("{id:int}")]
        public async Task<IActionResult> UpdateCustomer(int id, CreateCustomerDto Customer)
        {
            var customer = await _context.Customers.FindAsync(id);
            if (customer == null)
                return NotFound();

            customer.FullName = Customer.FullName;
            customer.Email = Customer.Email;
            customer.Phone = Customer.Phone;

            await _context.SaveChangesAsync();
            return NoContent();
        }
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteCustomer(int id)
        {
            var customer = await _context.Customers.FindAsync(id);
            if (customer == null)
                return NotFound();

            _context.Customers.Remove(customer);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
